//
// Created by kazem on 06/09/24.
//

#include <benchmark/benchmark.h>
#include "def.h"
#include "gemv.h"




static void BM_GEMV(benchmark::State &state, void (*gemvImpl1)(int M, int N, const float *A, const float *x, float *y,
                                                               swiftware::hpp::ScheduleParams Sp)) {

    int m = state.range(0);
    int n = state.range(1);
    //int k = state.range(2);
    int t1 = state.range(3);
    int t2 = state.range(4);
    auto *A = new swiftware::hpp::DenseMatrix(m, n);
    auto *B = new swiftware::hpp::DenseMatrix(1, n);
    auto *C = new swiftware::hpp::DenseMatrix(1, n);
    for (int i = 0; i < m * n; ++i) {
        A->data[i] = 1.0;
    }
    for (int i = 0; i < n; ++i) {
        B->data[i] = 1.0;
    }

    for (auto _: state) {
        gemvImpl1(m, n, A->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(t1, t2));
    }
    delete A;
    delete B;
    delete C;
}

BENCHMARK_CAPTURE(BM_GEMV, gemv, swiftware::hpp::gemv)->Args({512, 512, -1, -1})
        ->Args({1024, 1024, -1, -1})
        ->Args({2048, 2048, -1, -1})
        ->Args({4096, 4096, -1, -1});

BENCHMARK_CAPTURE(BM_GEMV, gemvT1, swiftware::hpp::gemvT1)->Args({512, 512, 512, 1024, -1})
        ->Args({1024, 1024, 1024, 1024, -1})
        ->Args({2048, 2048, 2048, 1024, -1})
        ->Args({4096, 4096, 4096, 1024, -1});
/*
//Commented out, used for optimizing GEMV
BENCHMARK_CAPTURE(BM_GEMV, gemvT1, swiftware::hpp::gemvT1)->Args({4096, 4096, 4096, 32, -1});
BENCHMARK_CAPTURE(BM_GEMV, gemvT1, swiftware::hpp::gemvT1)->Args({4096, 4096, 4096, 64, -1});
BENCHMARK_CAPTURE(BM_GEMV, gemvT1, swiftware::hpp::gemvT1)->Args({4096, 4096, 4096, 128, -1});
BENCHMARK_CAPTURE(BM_GEMV, gemvT1, swiftware::hpp::gemvT1)->Args({4096, 4096, 4096, 256, -1});
BENCHMARK_CAPTURE(BM_GEMV, gemvT1, swiftware::hpp::gemvT1)->Args({4096, 4096, 4096, 512, -1});
BENCHMARK_CAPTURE(BM_GEMV, gemvT1, swiftware::hpp::gemvT1)->Args({4096, 4096, 4096, 1024, -1});
*/

BENCHMARK_CAPTURE(BM_GEMV, gemvVec, swiftware::hpp::gemvT1)->Args({512, 512, 512, -1, -1})
        ->Args({1024, 1024, 1024, -1, -1})
        ->Args({2048, 2048, 2048, -1, -1})
        ->Args({4096, 4096, 4096, -1, -1});

BENCHMARK_MAIN();