// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include "gemm.h"

#include <immintrin.h>

namespace swiftware::hpp {
    void gemm(int m, int n, int k, const float *A, const float *B, float *C, ScheduleParams Sp) {
        for (int i = 0; i < m; i++) {
            for (int l = 0; l < k; l++) {
                float a_scal = A[i*k+l];
                for (int j = 0; j < n; j++) {
                    float b_scal = B[l*n+j];
                    C[i*n+j]+=a_scal * b_scal;
                }
            }
        }
    }

    void gemmT1(int m, int n, int k, const float *A, const float *B, float *C, ScheduleParams Sp) {

        int s = Sp.TileSize1;

        for (int i1 = 0; i1 < m; i1 += s) {
            for (int j1 = 0; j1 < n; j1 += s) {
                for (int l1 = 0; l1 < k; l1 += s) {
                    int imax = (i1 + s < m) ? i1 + s : m;
                    int jmax = (j1 + s < n) ? j1 + s : n;
                    int lmax = (l1 + s < k) ? l1 + s : k;
                    for (int i = i1; i < imax; ++i) {
                        for (int j = j1; j < jmax; ++j) {
                            for (int l = l1; l < lmax; ++l) {
                                C[i * n + j] += A[i * k + l] * B[l * n + j];
                            }
                        }
                    }
                }
            }
        }
    }

    void gemmT2(int m, int n, int k, const float *A, const float *B, float *C, ScheduleParams Sp) {
        int s = Sp.TileSize1; // Tile size for outer loops
        int t = Sp.TileSize2;    // Tile size for inner loops

        for (int i2 = 0; i2 < m; i2 += s) {
            int i2end = std::min(i2 + s, m);
            for (int l2 = 0; l2 < k; l2 += s) {
                int l2end = std::min(l2 + s, k);
                for (int j2 = 0; j2 < n; j2 += s) {
                    int j2end = std::min(j2 + s, n);
                    for (int i1 = i2; i1 < i2end; i1 += t) {
                        int i1end = std::min(i1 + t, i2end);
                        for (int l1 = l2; l1 < l2end; l1 += t) {
                            int l1end = std::min(l1 + t, l2end);
                            for (int j1 = j2; j1 < j2end; j1 += t) {
                                int j1end = std::min(j1 + t, j2end);
                                for (int i = i1; i < i1end; ++i) {
                                    for (int l = l1; l < l1end; ++l) {
                                        float a_il = A[i * k + l];
                                        for (int j = j1; j < j1end; ++j) {
                                            C[i * n + j] += a_il * B[l * n + j];
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    void gemmVectorized(int m, int n, int k, const float *A, const float *B, float *C, ScheduleParams Sp) {
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j += 8) {
                __m256 sum = _mm256_setzero_ps();
                for (int l = 0; l < k; l++) {
                    __m256 a = _mm256_set1_ps(A[i * k + l]);
                    __m256 b = _mm256_loadu_ps(&B[l * n + j]);
                    sum = _mm256_add_ps(sum, _mm256_mul_ps(a, b));
                }
                if (j + 8 <= n) {
                    _mm256_storeu_ps(&C[i * n + j], sum);
                } else {
                    // Handle the remaining elements if n is not a multiple of 8
                    float temp[8];
                    _mm256_storeu_ps(temp, sum);
                    for (int j0 = 0; j0 < n - j; j0++) {
                        C[i * n + j + j0] = temp[j0];
                    }
                }
            }
        }
    }
}
