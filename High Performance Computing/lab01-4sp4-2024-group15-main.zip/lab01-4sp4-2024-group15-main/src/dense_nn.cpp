// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab


#include "dense_nn.h"
#include <cmath>
#include <algorithm>
#include <iostream>

#include "gemm.h"
#include "gemv.h"




namespace swiftware::hpp {

    DenseMatrix *dense_nn_gemm(DenseMatrix *InData,
                               DenseMatrix *W1, DenseMatrix *W2, DenseMatrix *B1, DenseMatrix *B2, ScheduleParams Sp) {
        int batchSize = InData->m;//    !!(1,n) 1 row with n elements (col) but this is only the row = 1
        int featDim = InData->n; //     !!(1,n) 1 row with n elements (col) but this is only the col = n
        int hiddenDim = W1->m; //       !!(h,n) = h
        int outDim = W2->m; //          !!(m,n) = m


        DenseMatrix *out1 = new DenseMatrix(batchSize, hiddenDim); //(1,h)             !!H: Hidden layer activations (h-dimensional)
        DenseMatrix *out2 = new DenseMatrix(batchSize, outDim); //(1,m)                !!Z: Output vector before softmax (m-dimensional)
        DenseMatrix *pred = new DenseMatrix(batchSize, 1); //(1,1)?                    !!Y: Output vector (m-dimensional)
        auto predData = pred->data; //(m(data=n),1)                             !!Y(m,1)
        auto outDataVec = out2->data; //(m(data=n),h)                           !!Z(m,1)


        // TODO: Layer 1 Calculations: H = tanh(F * W1^T + B1)
        std::vector<float>T1(featDim*hiddenDim,0.0f);
        for (int i = 0; i < featDim; i++)
        {
            for (int j = 0; j < hiddenDim; j++)
            {
                T1[j+i*hiddenDim]= W1->data[j*featDim+i];
            }
        }


        std::vector<float>T2(hiddenDim*outDim,0.0f);
        for (int i = 0; i < hiddenDim; i++) //row
        {
            for (int j = 0; j < outDim; j++) //col
            {
                T2[j+i*outDim]= W2->data[j*hiddenDim+i];
            }
        }

        std::vector<float> XW_1(batchSize*hiddenDim,0.0f);
        gemmVectorized(batchSize,hiddenDim,featDim,InData->data.data(),T1.data(),XW_1.data(),Sp);


        for (int i = 0; i < batchSize; i++)
        {
            for (int j = 0; j < hiddenDim; j++)
            {
                out1->data[i*hiddenDim+j] = static_cast<float>(tanh(XW_1[i*hiddenDim+j]+B1->data[j]));
            }
        }



        // TODO: Layer 2 Calculations: O = sigmoid(H * W2^T + B2)

        std::vector<float>XW_2(batchSize*outDim,0.0f);
        gemmVectorized(batchSize,outDim,hiddenDim,out1->data.data(),T2.data(),XW_2.data(),Sp);


        for (int i = 0; i < batchSize; i++)
        {
            for (int j = 0; j < outDim; j++)
            {
                outDataVec[i*outDim+j] = static_cast<float>(1/(1 + exp(-(XW_2[i*outDim+j]+B2->data[j]))));
            }
        }

        // argmax
        for (int i = 0; i < batchSize; i++) {
            pred->data[i] = static_cast<int >(std::distance(outDataVec.begin() + i * outDim,
                                                          std::max_element(outDataVec.begin() + i * outDim,
                                                                           outDataVec.begin() + (i + 1) * outDim)));

        }
        return pred;

    }

    //TODO: Implement Dense NN with GEMV
    DenseMatrix *dense_nn_gemv(DenseMatrix *InData, DenseMatrix *W1, DenseMatrix *W2, DenseMatrix *B1, DenseMatrix *B2, ScheduleParams Sp){
        int batchSize = InData->m;//    !!(1,n) 1 row with n elements (col) but this is only the row = 1
        int featDim = InData->n; //     !!(1,n) 1 row with n elements (col) but this is only the col = n
        int hiddenDim = W1->m; //       !!(h,n) = h
        int outDim = W2->m; //          !!(m,n) = m


        DenseMatrix *out1 = new DenseMatrix(batchSize, hiddenDim); //(1,h)             !!H: Hidden layer activations (h-dimensional)
        DenseMatrix *out2 = new DenseMatrix(batchSize, outDim); //(1,m)                !!Z: Output vector before softmax (m-dimensional)
        DenseMatrix *pred = new DenseMatrix(batchSize, 1); //(1,1)?                    !!Y: Output vector (m-dimensional)
        auto predData = pred->data; //(m(data=n),1)                             !!Y(m,1)
        auto outDataVec = out2->data; //(m(data=n),h)                           !!Z(m,1)



        // // TODO: Layer 1 Calculations: H = tanh(F * W1^T + B1)
        for (int i = 0; i < batchSize; i++)
        {
            std::vector<float>XW_1(hiddenDim);
            std::vector<float>Xin(featDim);
            for (int j = 0; j < featDim; j++)
            {
                Xin[j]=InData->data[i*featDim+j];
            }
            gemv(hiddenDim,featDim,W1->data.data(),Xin.data(),XW_1.data(),Sp);

            for (int j = 0; j < hiddenDim; j++)
            {
                out1->data[i*hiddenDim+j] = static_cast<float>(tanh(XW_1[j]+B1->data[j]));

            }



            // TODO: Layer 2 Calculations: O = sigmoid(H * W2^T + B2)
            std::vector<float>XW_2(outDim);
            std::vector<float>O1(hiddenDim);
            for (int j = 0; j < hiddenDim; j++)
            {
                O1[j]=out1->data[i*hiddenDim+j];
            }

            gemv(outDim,hiddenDim,W2->data.data(),O1.data(),XW_2.data(),Sp);

            for (int j = 0; j < outDim; j++) //col
            {
                outDataVec[i*outDim+j] = static_cast<float>(1/(1 + exp(-(XW_2[j]+B2->data[j]))));
            }
        }

        // argmax
        for (int i = 0; i < batchSize; i++) {
            pred->data[i] = static_cast<int >(std::distance(outDataVec.begin() + i*outDim,std::max_element(outDataVec.begin() + i*outDim,outDataVec.begin() + (i+1)*outDim)));
        }

        return pred;
    }
}
