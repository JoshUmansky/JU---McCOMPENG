// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab


#include <gtest/gtest.h>
#include "gemm.h"

namespace swiftware::hpp {
 // helper function to generate and populate array with random data for testing
 void populate_array(float* array, int size) {
  std::srand(static_cast<unsigned int>(std::time(0)));
  for (int i = 0; i < size; ++i) {
   array[i] = 1 + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (1000 - 1)));
  }
 }

 TEST(GEMMTest, SmallTest) {
  int m = 2;
  int n = 2;
  int k = 2;
  // TODO replace below with DenseMatrix
  float A[4] = {1, 2, 3, 4};
  float B[4] = {1, 2, 3, 4};
  float C[4] = {0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[4] = {7, 10, 15, 22};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, SmallTestT1) {
  int m = 2;
  int n = 2;
  int k = 2;
  float A[4] = {1, 2, 3, 4};
  float B[4] = {1, 2, 3, 4};
  float C[4] = {0, 0, 0, 0};
  swiftware::hpp::gemmT1(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[4] = {7, 10, 15, 22};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, LargeTestT1) {
  int m = 4;
  int n = 4;
  int k = 4;
  float A[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
  float B[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
  float C[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmT1(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[16] = {90, 100, 110, 120, 202, 228, 254, 280, 314, 356, 398, 440, 426, 484, 542, 600};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, RandomTestT1) {
  int m = 4;
  int n = 4;
  int k = 4;
  float A[16];
  float B[16];
  populate_array(A, 16);
  populate_array(B, 16);
  float C[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmT1(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32));
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, EdgeTestT1) {
  int m = 4;
  int n = 4;
  int k = 4;
  float A[16] = {1, 0, 3, 24, 0.0005, 12, 305, 2.5, 6, 23, 11, 42, 5.5, 405, 64, 10.1};
  float B[16] = {4, 54, 76, 67, 5005, 566, 23.75, 52.09, 44, 12, 0, 0.5, 5.89, 8.89, 9.04, 22};
  float C[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmT1(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[16] = {277.36, 303.36, 292.96, 596.5, 73494.727, 10474.252, 307.638, 832.6135, 115870.38, 13847.38, 1381.93, 2529.57, 2029922.489, 230384.789, 10128.054, 21719.15};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e-2);
   }
  }
 }

 TEST(GEMMTest, SmallTestT2) {
  int m = 2;
  int n = 2;
  int k = 2;
  float A[4] = {1, 2, 3, 4};
  float B[4] = {1, 2, 3, 4};
  float C[4] = {0, 0, 0, 0};
  swiftware::hpp::gemmT2(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[4] = {7, 10, 15, 22};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, LargeTestT2) {
  int m = 4;
  int n = 4;
  int k = 4;
  float A[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
  float B[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
  float C[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmT2(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[16] = {90, 100, 110, 120, 202, 228, 254, 280, 314, 356, 398, 440, 426, 484, 542, 600};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, RandomTestT2) {
  int m = 4;
  int n = 4;
  int k = 4;
  float A[16];
  float B[16];
  populate_array(A, 16);
  populate_array(B, 16);
  float C[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmT2(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32));
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, EdgeTestT2) {
  int m = 4;
  int n = 4;
  int k = 4;
  float A[16] = {1, 0, 3, 24, 0.0005, 12, 305, 2.5, 6, 23, 11, 42, 5.5, 405, 64, 10.1};
  float B[16] = {4, 54, 76, 67, 5005, 566, 23.75, 52.09, 44, 12, 0, 0.5, 5.89, 8.89, 9.04, 22};
  float C[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmT2(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[16] = {277.36, 303.36, 292.96, 596.5, 73494.727, 10474.252, 307.638, 832.6135, 115870.38, 13847.38, 1381.93, 2529.57, 2029922.489, 230384.789, 10128.054, 21719.15};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e-2);
   }
  }
 }

 TEST(GEMMTest, SmallTestVec) {
  int m = 2;
  int n = 2;
  int k = 2;
  // TODO replace below with DenseMatrix
  float A[4] = {1, 2, 3, 4};
  float B[4] = {1, 2, 3, 4};
  float C[4] = {0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[4] = {7, 10, 15, 22};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, SmallRandomTestVec) {
  int m = 4;
  int n = 4;
  int k = 4;
  float A[16];
  float B[16];
  populate_array(A, 16);
  populate_array(B, 16);
  float C[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32));
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e-2);
   }
  }
 }

 TEST(GEMMTest, SmallEdgeTestVec) {
  int m = 4;
  int n = 4;
  int k = 4;
  float A[16] = {1, 0, 3, 24, 0.0005, 12, 305, 2.5, 6, 23, 11, 42, 5.5, 405, 64, 10.1};
  float B[16] = {4, 54, 76, 67, 5005, 566, 23.75, 52.09, 44, 12, 0, 0.5, 5.89, 8.89, 9.04, 22};
  float C[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[16] = {277.36, 303.36, 292.96, 596.5, 73494.727, 10474.252, 307.638, 832.6135, 115870.38, 13847.38, 1381.93, 2529.57, 2029922.489, 230384.789, 10128.054, 21719.15};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e-2);
   }
  }
 }

  TEST(GEMMTest, BasicLargeTestVec) {
  int m = 8;
  int n = 8;
  int k = 8;
  float A[64] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
  float B[64] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
  float C[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[64] = {8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8};
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, LargeTestVec) {
  int m = 8;
  int n = 8;
  int k = 8;
  float A[64] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64};
  float B[64] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64};
  float C[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32));
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_EQ(C[i * n + j], expected[i * n + j]);
   }
  }
 }

 TEST(GEMMTest, LargeRandomTestVec) {
  int m = 8;
  int n = 8;
  int k = 8;
  float A[64];
  float B[64];
  populate_array(A, 64);
  populate_array(B, 64);
  float C[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32));
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e-2);
   }
  }
 }

 TEST(GEMMTest, LargeEdgeTestVec) {
  int m = 8;
  int n = 8;
  int k = 8;
  float A[64] = {1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1, 1e-5, 1e5, 0, 1};
  float B[64] = {1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5, 1, 0, 1e5, 1e-5};
  float C[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32));
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e-2);
   }
  }
 }

 TEST(GEMMTest, VeryLargeRandomTestVec) {
  int m = 16;
  int n = 16;
  int k = 16;
  float A[256];
  float B[256];
  populate_array(A, 256);
  populate_array(B, 256);
  float C[256] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[256] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32));
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e-2);
   }
  }
 }

  TEST(GEMMTest, NoneDivisibleLargeRandomTestVec) {
  int m = 13;
  int n = 13;
  int k = 13;
  float A[169];
  float B[169];
  populate_array(A, 169);
  populate_array(B, 169);
  float C[169] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemmVectorized(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[169] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  swiftware::hpp::gemm(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32));
  for (int i = 0; i < m; ++i) {
   for (int j = 0; j < n; ++j) {
    EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e-2);
   }
  }
 }
}