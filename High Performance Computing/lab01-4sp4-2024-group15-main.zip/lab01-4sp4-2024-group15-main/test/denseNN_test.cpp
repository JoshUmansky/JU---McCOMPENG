// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include <gtest/gtest.h>
#include "dense_nn.h"

namespace swiftware::hpp {
 // TODO




}