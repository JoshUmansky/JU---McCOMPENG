// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include "gemv.h"
#include <gtest/gtest.h>

namespace swiftware::hpp {
    // helper function to generate and populate array with random data for testing
    void populate_array(float* array, int size)
    {
        std::srand(static_cast<unsigned int>(std::time(0)));
        for (int i = 0; i < size; ++i) {
            array[i] = 1 + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (1000 - 1)));
        }
    }
    TEST(GEMVTest, SmallTest) {
        int m = 2;
        int n = 2;
        float A[4] = {1, 2, 3, 4};
        float B[2] = {1, 2};
        float C[2] = {0, 0};
        swiftware::hpp::gemv(m, n, A, B,  C, swiftware::hpp::ScheduleParams(-1, -1));
        float expected[2] = {5, 11};
        for (int i = 0; i < m; ++i) {
                EXPECT_EQ(C[i], expected[i]);
        }
    }
    TEST(GEMVTest, SmallTestT1) {
        int m = 2;
        int n = 2;
        float A[4] = {1, 2, 3, 4};
        float B[2] = {1, 2};
        float C[2] = {0, 0};
        swiftware::hpp::gemvT1(m, n, A, B,  C, swiftware::hpp::ScheduleParams(32, -1));
        float expected[2] = {5, 11};
        for (int i = 0; i < m; ++i) {
            EXPECT_EQ(C[i], expected[i]);
        }
    }
    TEST(GEMVTest, LargeTest) {
        int m = 1000;
        int n = 1000;
        std::vector<float> A(m * n);
        std::vector<float> B(n);
        std::vector<float> C(m, 0);
        // Initialize matrices with some values
        std::fill(A.begin(), A.end(), 1.0f);
        std::fill(B.begin(), B.end(), 1.0f);
        swiftware::hpp::gemv(m, n, A.data(), B.data(), C.data(), swiftware::hpp::ScheduleParams(-1, -1));
        for (int i = 0; i < m; ++i) {
            EXPECT_FLOAT_EQ(C[i], n);
        }
    }
    TEST(GEMVTest, ZeroMatrixTest) {
        int m = 5;
        int n = 5;
        float A[25] = {0};
        float B[5] = {1, 2, 3, 4, 5};
        float C[5] = {0};
        swiftware::hpp::gemv(m, n, A, B, C, swiftware::hpp::ScheduleParams(-1, -1));
        float expected[5] = {0, 0, 0, 0, 0};
        for (int i = 0; i < m; ++i) {
            EXPECT_EQ(C[i], expected[i]);
        }
    }
    TEST(GEMVTest, UnitMatrixTest) {
        int m = 3;
        int n = 3;
        float A[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
        float B[3] = {5, 6, 7};
        float C[3] = {0};
        swiftware::hpp::gemv(m, n, A, B, C, swiftware::hpp::ScheduleParams(-1, -1));
        float expected[3] = {5, 6, 7};
        for (int i = 0; i < m; ++i) {
            EXPECT_EQ(C[i], expected[i]);
        }
    }
    TEST(GEMVTest, SingularVectorTestT1) {
        int m = 4;
        int n = 4;
        float A[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        float B[4] = {1, 1, 1, 1};
        float C[4] = {0};
        swiftware::hpp::gemvT1(m, n, A, B, C, swiftware::hpp::ScheduleParams(32, -1));
        float expected[4] = {10, 26, 42, 58};
        for (int i = 0; i < n; ++i) {
            EXPECT_EQ(C[i], expected[i]);
        }
    }
    TEST(GEMVTest, ZeroVectorTestT1) {
        int m = 3;
        int n = 3;
        float A[9] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        float B[3] = {0, 0, 0};
        float C[3] = {0};
        swiftware::hpp::gemvT1(m, n, A, B, C, swiftware::hpp::ScheduleParams(32, -1));
        float expected[3] = {0, 0, 0};
        for (int i = 0; i < n; ++i) {
            EXPECT_EQ(C[i], expected[i]);
        }
    }
    TEST(GEMVTest, GemVVectorizedTest) {
        int m = 4;
        int n = 4;
        float A[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        float B[4] = {1, 1, 1, 1};
        float C[4] = {0};
        swiftware::hpp::gemvVec(m, n, A, B, C, swiftware::hpp::ScheduleParams(32, -1));
        float expected[4] = {10, 26, 42, 58};
        for (int i = 0; i < n; ++i) {
            EXPECT_EQ(C[i], expected[i]);
        }
    }

    TEST(GEMMTest, VeryLargeRandomTestVVec) {
        int m = 16;
        int n = 16;
        float A[256];
        float B[16];
        populate_array(A, 256);
        populate_array(B, 16);
        float C[16] = {0};
        swiftware::hpp::gemvT1(m, n, A, B, C, swiftware::hpp::ScheduleParams(32, -1));
        float expected[16] = {0};
        swiftware::hpp::gemv(m, n, A, B, expected, swiftware::hpp::ScheduleParams(32, -1));
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < n; ++j) {
                EXPECT_NEAR(C[i], expected[i], 1);
            }
        }
    }
}