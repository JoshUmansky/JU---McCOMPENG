//
// Created by kazem on 06/09/24.
//

#include <benchmark/benchmark.h>
#include <iostream>
#include "dense_nn.h"
#include "utils.h"

// TODO : Implement the benchmark

static void BM_DENSENN(benchmark::State &state,
                       swiftware::hpp::DenseMatrix *(*denseNNImpl)(swiftware::hpp::DenseMatrix *InData,
                                                                   swiftware::hpp::DenseMatrix *W1,
                                                                   swiftware::hpp::DenseMatrix *W2,
                                                                   swiftware::hpp::DenseMatrix *B1,
                                                                   swiftware::hpp::DenseMatrix *B2,
                                                                   swiftware::hpp::ScheduleParams Sp),bool valid)
{
    // data folder should be under the project folder. Change the working directory when using CLion so it points
    // to where the data directory is located.
    std::string dataFolder = "./data";
    int samples = static_cast<int>(state.range(0));

    auto *mnistData = swiftware::hpp::readCSV(dataFolder + "/mnist_train.csv", true);

    if (valid)
    {
        samples = std::min(samples,mnistData->m); // for gemv
    }
    else
    {
        samples = mnistData->m; // for gemm
    }


    auto *labels = new swiftware::hpp::DenseMatrix(samples, 1);
    auto *features = new swiftware::hpp::DenseMatrix(samples, mnistData->n - 1);
    //TODO: Extract labels and features from mnist dataset
    for (int i = 0; i < samples; i++)
    {
        labels->data[i]=mnistData->data[i*mnistData->n];
        for (int j = 1; j < mnistData->n; j++)
        {
            features->data[i*(mnistData->n-1)+(j-1)]=mnistData->data[i*mnistData->n + j];
        }
    }

    auto *weightsOutput = swiftware::hpp::readCSV(dataFolder + "/model/weights_output.csv");
    auto *weightsHidden = swiftware::hpp::readCSV(dataFolder + "/model/weights_hidden.csv");
    auto *biasesHidden = swiftware::hpp::readCSV(dataFolder + "/model/biases_hidden.csv");
    auto *biasesOutput = swiftware::hpp::readCSV(dataFolder + "/model/biases_output.csv");
    swiftware::hpp::ScheduleParams scheduleParams(1024, 1024);
    //TODO : Implement the benchmark


    for (auto _: state) {
        int correct = 0;

        // Running the NN function
        auto *result = denseNNImpl(features, weightsHidden, weightsOutput, biasesHidden, biasesOutput, scheduleParams);

        // TODO: Calculate accuracy
        for (int i = 0; i < result->m; i++)
        {

            if (result->data[i] == labels->data[i])
            {
                correct++;
            }
        }


        float accuracy = (static_cast<float>(correct)/static_cast<float>(features->m))*100;
        std::cout <<"Accuracy: "<< accuracy <<"%" << std::endl;

    }



    delete mnistData;
    delete labels;
    delete features;
    delete weightsOutput;
    delete weightsHidden;
    delete biasesHidden;
    delete biasesOutput;

}


BENCHMARK_CAPTURE(BM_DENSENN, dense_nn_gemm, swiftware::hpp::dense_nn_gemm,false)->Arg(10);
BENCHMARK_CAPTURE(BM_DENSENN, dense_nn_gemv, swiftware::hpp::dense_nn_gemv,true)->Arg(10);

BENCHMARK_MAIN();