// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab


#include <gtest/gtest.h>
#include "gemm.h"
#include "err_code.h"

namespace swiftware::hpp {
  // helper function to generate and populate array with random data for testing
  void populate_array(float* array, int size) {
    std::srand(static_cast<unsigned int>(std::time(0)));
    for (int i = 0; i < size; ++i) {
      array[i] = 1 + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (1000 - 1)));
    }
  }

  // Kernel sources
  const char *KernelSourceV1 = "\n" \
"__kernel void matmul_v1(                             \n" \
"   __global float* a,                                \n" \
"   __global float* b,                                \n" \
"   __global float* c,                                \n" \
"   const int M,                                      \n" \
"   const int N,                                      \n" \
"   const int K)                                      \n" \
"{                                                    \n" \
"   int i = get_global_id(0);                         \n" \
"   if (i < M){                                       \n" \
"       for (int j = 0; j < N; j++){                  \n" \
"           float sum=0;                              \n" \
"           for (int k=0;k<K;k++){                    \n" \
"              sum += a[i*K+k] * b[k*N+j];            \n" \
"           }                                         \n" \
"           c[i*N+j] = sum;                           \n" \
"       }                                             \n" \
"   }                                                 \n" \
"}                                                    \n" \
"\n";

const char *KernelSourceV2 = "\n" \
"__kernel void matmul_v2(                             \n" \
"   __global float* a,                                \n" \
"   __global float* b,                                \n" \
"   __global float* c,                                \n" \
"   const int M,                                      \n" \
"   const int N,                                      \n" \
"   const int K)                                      \n" \
"{                                                    \n" \
"   int row = get_global_id(0);                       \n" \
"   int col = get_global_id(1);                       \n" \
"   if (row < M && col < N) {                         \n" \
"       float sum = 0;                                \n" \
"       for (int k = 0; k < K; k++) {                 \n" \
"           sum += a[row * K + k] * b[k * N + col];   \n" \
"       }                                             \n" \
"       c[row * N + col] = sum;                       \n" \
"   }                                                 \n" \
"}                                                    \n" \
"\n";

const char *KernelSourceV3 = "\n" \
"__kernel void matmul_v3(                             \n" \
"   __global float* a,                                \n" \
"   __global float* b,                                \n" \
"   __global float* c,                                \n" \
"   const int M,                                      \n" \
"   const int N,                                      \n" \
"   const int K)                                      \n" \
"{                                                    \n" \
"    int row = get_global_id(0);                      \n" \
"    int col = get_global_id(1);                      \n" \
"    int local_row = get_local_id(0);                 \n" \
"    int local_col = get_local_id(1);                 \n" \
"    int tile_size = 16;                              \n" \
"    __local float tile_a[16][16];                    \n" \
"    __local float tile_b[16][16];                    \n" \
"    float sum = 0;                                   \n" \
"    for (int t = 0; t < (K + tile_size - 1) / tile_size; t++) {                                                  \n" \
"        int tiled_col = t * tile_size + local_col;                                                               \n" \
"        int tiled_row = t * tile_size + local_row;                                                               \n" \
"        tile_a[local_row][local_col] = (row < M && tiled_col < K) ? a[row * K + tiled_col] : 0.0f;               \n" \
"        tile_b[local_row][local_col] = (col < N && tiled_row < K) ? b[tiled_row * N + col] : 0.0f;               \n" \
"        barrier(CLK_LOCAL_MEM_FENCE);                                                                            \n" \
"        for (int k = 0; k < tile_size; k++) {                                                                    \n" \
"            sum += tile_a[local_row][k] * tile_b[k][local_col];                                                  \n" \
"        }                                            \n" \
"        barrier(CLK_LOCAL_MEM_FENCE);                \n" \
"    }                                                \n" \
"    if (row < M && col < N) {                        \n" \
"        c[row * N + col] = sum;                      \n" \
"    }                                                \n" \
"}                                                    \n" \
"\n";

  // helper function to run kernel
  void runKernel(const char *kernelSource, const char *kernelName, int work_dim, int m, int n, int k, float *A, float *B, float *C) {
    // Initialize OpenCL
    cl_platform_id platform_id = NULL;
    cl_device_id device_id = NULL;
    cl_context context = NULL;
    cl_command_queue command_queue = NULL;
    cl_program program = NULL;
    cl_kernel kernel = NULL;

    cl_uint num_platforms;
    clGetPlatformIDs(0, NULL, &num_platforms);
    cl_platform_id* platforms = (cl_platform_id*)malloc(num_platforms * sizeof(cl_platform_id));
    clGetPlatformIDs(num_platforms, platforms, NULL);

    cl_bool found_gpu_platform = CL_FALSE;
    for (cl_uint i = 0; i < num_platforms; ++i) {
        cl_uint num_devices;
        clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_GPU, 0, NULL, &num_devices);
        if (num_devices > 0) {
            clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);
            found_gpu_platform = CL_TRUE;
            break;
        }
    }

    if (!found_gpu_platform) {
        std::cerr << "No GPU device found." << std::endl;
    }

    int err;
    context = clCreateContext(0, 1, &device_id, NULL, NULL, &err);
    checkError(err, "Creating context");
    cl_queue_properties properties[] = {CL_QUEUE_PROPERTIES, CL_QUEUE_PROFILING_ENABLE, 0};
    command_queue = clCreateCommandQueueWithProperties(context, device_id, properties, &err);
    checkError(err, "Creating command queue");

    program = clCreateProgramWithSource(context, 1, (const char **) & kernelSource, NULL, &err);
    checkError(err, "Creating program");

    err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
    if (err != CL_SUCCESS) {
        size_t len;
        char buffer[2048];
        printf("Error: Failed to build program executable!\n%s\n", err_code(err));
        clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
        printf("%s\n", buffer);
    }

    kernel = clCreateKernel(program, kernelName, &err);
    checkError(err, "Creating kernel");

    cl_mem buffer_a = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, m * k * sizeof(float), A, NULL);
    cl_mem buffer_b = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, k * n * sizeof(float), B, NULL);
    cl_mem buffer_c = clCreateBuffer(context, CL_MEM_WRITE_ONLY, m * n * sizeof(float), NULL, NULL);

    clSetKernelArg(kernel, 0, sizeof(cl_mem), (void *)&buffer_a);
    clSetKernelArg(kernel, 1, sizeof(cl_mem), (void *)&buffer_b);
    clSetKernelArg(kernel, 2, sizeof(cl_mem), (void *)&buffer_c);
    clSetKernelArg(kernel, 3, sizeof(int), (void *)&m);
    clSetKernelArg(kernel, 4, sizeof(int), (void *)&n);
    clSetKernelArg(kernel, 5, sizeof(int), (void *)&k);

    size_t global_work_size[2];
    size_t local_work_size[2];

    if (work_dim == 1) {
        global_work_size[0] = m;
        local_work_size[0] = 2;
    } else {
        size_t padded_m = ((m + 15) / 16) * 16;
        size_t padded_n = ((n + 15) / 16) * 16;
        global_work_size[0] = padded_m;
        global_work_size[1] = padded_n;

        // Query the maximum work group size
        size_t max_work_group_size;
        clGetKernelWorkGroupInfo(kernel, device_id, CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t), &max_work_group_size, NULL);

        // Ensure local work size does not exceed the maximum work group size
        local_work_size[0] = 16;
        local_work_size[1] = 16;
        if (local_work_size[0] * local_work_size[1] > max_work_group_size) {
            local_work_size[0] = max_work_group_size / 16;
            local_work_size[1] = 16;
        }
    }

    cl_event event = nullptr;
    err = clEnqueueNDRangeKernel(command_queue, kernel, work_dim, NULL, global_work_size, local_work_size, 0, NULL, &event);
    checkError(err, "Enqueueing kernel");
    clWaitForEvents(1, &event);
    clEnqueueReadBuffer(command_queue, buffer_c, CL_TRUE, 0, m * n * sizeof(float), C, 0, NULL, NULL);

    clReleaseKernel(kernel);
    clReleaseProgram(program);
    clReleaseCommandQueue(command_queue);
    clReleaseContext(context);
    clReleaseMemObject(buffer_a);
    clReleaseMemObject(buffer_b);
    clReleaseMemObject(buffer_c);
    free(platforms);
  }

  TEST(MMTest, Kernel1Test) {
    int m = 2;
    int n = 2;
    int k = 2;
    float A[4] = {1, 2, 3, 4};
    float B[4] = {1, 2, 3, 4};
    float C[4] = {0, 0, 0, 0};
    float expected[4] = {7, 10, 15, 22};

    runKernel(KernelSourceV1, "matmul_v1", 1, m, n, k, A, B, C);

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C[i * n + j], expected[i * n + j]);
      }
    }
  }

  TEST(MMTest, Kernel2Test) {
    int m = 2;
    int n = 2;
    int k = 2;
    float A[4] = {1, 2, 3, 4};
    float B[4] = {1, 2, 3, 4};
    float C[4] = {0, 0, 0, 0};
    float expected[4] = {7, 10, 15, 22};

    runKernel(KernelSourceV2, "matmul_v2", 2, m, n, k, A, B, C);

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C[i * n + j], expected[i * n + j]);
      }
    }
  }

  TEST(MMTest, Kernel3Test) {
    int m = 2;
    int n = 2;
    int k = 2;
    float A[4] = {1, 2, 3, 4};
    float B[4] = {1, 2, 3, 4};
    float C[4] = {0, 0, 0, 0};
    float expected[4] = {7, 10, 15, 22};

    runKernel(KernelSourceV3, "matmul_v3", 2, m, n, k, A, B, C);

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C[i * n + j], expected[i * n + j]);
      }
    }
  }

  TEST(MMTest, SmallTest) {
    int m = 2;
    int n = 2;
    int k = 2;
    // TODO generate random sparse matrices
    float A[4] = {1, 2, 3, 4};
    float B[4] = {1, 2, 3, 4};
    float C[4] = {0, 0, 0, 0};
    swiftware::hpp::gemmEfficientParallel(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(32, 32, 8, 1));
    float expected[4] = {7, 10, 15, 22};
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C[i * n + j], expected[i * n + j]);
      }
    }
  }

  // TODO add more tests for GEMM OpenCL

  TEST(MMTest, Kernel1LargeTest) {
      int m = 8;
      int n = 8;
      int k = 8;
      float A[64], B[64];
      float C[64] = {0};
      float expected[64] = {0};
      populate_array(A, 64);
      populate_array(B, 64);
      runKernel(KernelSourceV1, "matmul_v1", 1, m, n, k, A, B, C);
      swiftware::hpp::gemmEfficientParallel(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32, 8, 1));
      for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
          EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e0);
        }
      }
    }

  TEST(MMTest, Kernel2LargeTest) {
      int m = 8;
      int n = 8;
      int k = 8;
      float A[64], B[64];
      float C[64] = {0};
      float expected[64] = {0};
      populate_array(A, 64);
      populate_array(B, 64);
      runKernel(KernelSourceV2, "matmul_v2", 2, m, n, k, A, B, C);
      swiftware::hpp::gemmEfficientParallel(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32, 8, 1));
      for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
          EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e0);
        }
      }
    }

  TEST(MMTest, Kernel3LargeTest) {
      int m = 8;
      int n = 8;
      int k = 8;
      float A[64], B[64];
      float C[64] = {0};
      float expected[64] = {0};
      populate_array(A, 64);
      populate_array(B, 64);
      runKernel(KernelSourceV3, "matmul_v3", 2, m, n, k, A, B, C);
      swiftware::hpp::gemmEfficientParallel(m, n, k, A, B, expected, swiftware::hpp::ScheduleParams(32, 32, 8, 1));
      for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
          EXPECT_NEAR(C[i * n + j], expected[i * n + j], 1e0);
        }
      }
    }
}