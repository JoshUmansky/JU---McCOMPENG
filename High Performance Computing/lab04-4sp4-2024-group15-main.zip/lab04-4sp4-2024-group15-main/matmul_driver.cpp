// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab


#ifdef __APPLE__
#include <OpenCL/cl.hpp>
#else
#include <CL/opencl.h>
#endif

#include <iostream>
#include <benchmark/benchmark.h>
#include <chrono>

#include "err_code.h"
#include "gemm.h"

#define NUM_THREADS 8

static void BM_GEMM(benchmark::State &state,
                    void (*gemmImpl1)(int M, int N, int K, const float *A, const float *B, float *C,
                                      swiftware::hpp::ScheduleParams Sp)) {
  int m = state.range(0);
  int n = state.range(1);
  int k = state.range(2);
  int t1 = state.range(3);
  int t2 = state.range(4);
  int cs = state.range(5); // chunk size
  int nt = state.range(6); // number of threads
  // TOOO : add other parameters if needed

  auto *A = new swiftware::hpp::DenseMatrix(m, k);
  auto *B = new swiftware::hpp::DenseMatrix(k, n);
  auto *C = new swiftware::hpp::DenseMatrix(m, n);
  for (int i = 0; i < m * k; ++i) {
    A->data[i] = 1.0;
  }
  for (int i = 0; i < k * n; ++i) {
    B->data[i] = 1.0;
  }

  for (auto _: state) {
    gemmImpl1(m, n, k, A->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(t1, t2, nt, cs));
  }
  delete A;
  delete B;
  delete C;

}

#ifdef __OPENCL__
// TODO: Implement the benchmark for OpenCL GEMM
const char *KernelSourceV1 = "\n" \
"__kernel void matmul_v1(                             \n" \
"   __global float* a,                                \n" \
"   __global float* b,                                \n" \
"   __global float* c,                                \n" \
"   const int M,                                      \n" \
"   const int N,                                      \n" \
"   const int K)                                      \n" \
"{                                                    \n" \
"   int i = get_global_id(0);                         \n" \
"   if (i < M){                                       \n" \
"       for (int j = 0; j < N; j++){                  \n" \
"           float sum=0;                              \n" \
"           for (int k=0;k<K;k++){                    \n" \
"              sum += a[i*K+k] * b[k*N+j];            \n" \
"           }                                         \n" \
"           c[i*N+j] = sum;                           \n" \
"       }                                             \n" \
"   }                                                 \n" \
"}                                                    \n" \
"\n";

const char *KernelSourceV2 = "\n" \
"__kernel void matmul_v2(                             \n" \
"   __global float* a,                                \n" \
"   __global float* b,                                \n" \
"   __global float* c,                                \n" \
"   const int M,                                      \n" \
"   const int N,                                      \n" \
"   const int K)                                      \n" \
"{                                                    \n" \
"   int row = get_global_id(0);                       \n" \
"   int col = get_global_id(1);                       \n" \
"   if (row < M && col < N) {                         \n" \
"       float sum = 0;                                \n" \
"       for (int k = 0; k < K; k++) {                 \n" \
"           sum += a[row * K + k] * b[k * N + col];   \n" \
"       }                                             \n" \
"       c[row * N + col] = sum;                       \n" \
"   }                                                 \n" \
"}                                                    \n" \
"\n";

const char *KernelSourceV3 = "\n" \
"__kernel void matmul_v3(                             \n" \
"   __global float* a,                                \n" \
"   __global float* b,                                \n" \
"   __global float* c,                                \n" \
"   const int M,                                      \n" \
"   const int N,                                      \n" \
"   const int K)                                      \n" \
"{                                                    \n" \
"    int row = get_global_id(0);                      \n" \
"    int col = get_global_id(1);                      \n" \
"    int local_row = get_local_id(0);                 \n" \
"    int local_col = get_local_id(1);                 \n" \
"    int tile_size = 16;                              \n" \
"    __local float tile_a[16][16];                    \n" \
"    __local float tile_b[16][16];                    \n" \
"    float sum = 0;                                   \n" \
"    for (int t = 0; t < (K + tile_size - 1) / tile_size; t++) {                                                  \n" \
"        int tiled_col = t * tile_size + local_col;                                                               \n" \
"        int tiled_row = t * tile_size + local_row;                                                               \n" \
"        tile_a[local_row][local_col] = (row < M && tiled_col < K) ? a[row * K + tiled_col] : 0.0f;               \n" \
"        tile_b[local_row][local_col] = (col < N && tiled_row < K) ? b[tiled_row * N + col] : 0.0f;               \n" \
"        barrier(CLK_LOCAL_MEM_FENCE);                                                                            \n" \
"        for (int k = 0; k < tile_size; k++) {                                                                    \n" \
"            sum += tile_a[local_row][k] * tile_b[k][local_col];                                                  \n" \
"        }                                            \n" \
"        barrier(CLK_LOCAL_MEM_FENCE);                \n" \
"    }                                                \n" \
"    if (row < M && col < N) {                        \n" \
"        c[row * N + col] = sum;                      \n" \
"    }                                                \n" \
"}                                                    \n" \
"\n";

// TODO: edit the benchmark to run different OpenCL GEMM implementations
static void BM_MATMUL_OPENCL(benchmark::State &state,
                             const char *kernelSource,
                             const char *kernelName) {
    int m = state.range(0);
    int n = state.range(1);
    int k = state.range(2);
    int work_dim = state.range(3);


    auto *A = new swiftware::hpp::DenseMatrix(m, k);
    auto *B = new swiftware::hpp::DenseMatrix(k, n);
    auto *C = new swiftware::hpp::DenseMatrix(m, n);
    for (int i = 0; i < m * k; ++i) {
        A->data[i] = 1.0;
    }
    for (int i = 0; i < k * n; ++i) {
        B->data[i] = 1.0;
    }
    // declare device containers
    // Initialize OpenCL
    cl_platform_id platform_id = NULL;
    cl_device_id device_id = NULL;
    cl_context context = NULL;
    cl_command_queue command_queue = NULL;
    cl_program program = NULL;
    cl_kernel kernel = NULL;

    // Get the number of platforms
    cl_uint num_platforms;
    clGetPlatformIDs(0, NULL, &num_platforms);

    // Get the platforms
    cl_platform_id* platforms = (cl_platform_id*)malloc(num_platforms * sizeof(cl_platform_id));
    clGetPlatformIDs(num_platforms, platforms,
                     NULL);

    // Find a GPU platform
    cl_bool found_gpu_platform = CL_FALSE;
    for (cl_uint i = 0; i < num_platforms; ++i) {
        cl_uint num_devices;
        clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_GPU, 0, NULL, &num_devices);

        if (num_devices > 0) {
            clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);
            found_gpu_platform = CL_TRUE;
            break;
        }
    }

    if (!found_gpu_platform) {
        std::cerr << "No GPU device found." << std::endl;
    }

    // Get device information
    char device_name[1024];
    clGetDeviceInfo(device_id, CL_DEVICE_NAME, sizeof(device_name), device_name, NULL);

    int err;
    // Create a compute context
    context = clCreateContext(0, 1, &device_id, NULL, NULL, &err);
    checkError(err, "Creating context");
    // create cl_queue_properties
    cl_queue_properties properties[] = {CL_QUEUE_PROPERTIES, CL_QUEUE_PROFILING_ENABLE, 0};
    // Create a command queue
    command_queue = clCreateCommandQueueWithProperties(context, device_id,
                                                       properties, &err);
    checkError(err, "Creating command queue");


    // Create the compute program from the source buffer
    program = clCreateProgramWithSource(context, 1, (const char **) & kernelSource, NULL, &err);
    checkError(err, "Creating program");

    // Build the program
    err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
    if (err != CL_SUCCESS)
    {
        size_t len;
        char buffer[2048];

        printf("Error: Failed to build program executable!\n%s\n", err_code(err));
        clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
        printf("%s\n", buffer);
    }

    // Create the compute kernel from the program
    kernel = clCreateKernel(program, kernelName, &err);
    checkError(err, "Creating kernel");

    // Create device buffers
    cl_mem buffer_a = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, m * k * sizeof(float), A->data.data(), NULL);
    cl_mem buffer_b = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, k * n * sizeof(float), B->data.data(), NULL);
    cl_mem buffer_c = clCreateBuffer(context, CL_MEM_WRITE_ONLY, m * n * sizeof(float), NULL, NULL);

    // Set kernel arguments
    clSetKernelArg(kernel, 0, sizeof(cl_mem), (void *)&buffer_a);
    clSetKernelArg(kernel, 1, sizeof(cl_mem), (void *)&buffer_b);
    clSetKernelArg(kernel, 2, sizeof(cl_mem), (void *)&buffer_c);
    clSetKernelArg(kernel, 3, sizeof(int), (void *)&m);
    clSetKernelArg(kernel, 4, sizeof(int), (void *)&n);
    clSetKernelArg(kernel, 5, sizeof(int), (void *)&k);

    // Set kernel global and local work size Hardcoded for now
    size_t global_work_size[2];
    size_t local_work_size[2];
    if (work_dim == 1) {
        global_work_size[0] = m;
        local_work_size[0] = 16;
    } else {
        size_t padded_m = ((m + 15) / 16) * 16;
        size_t padded_n = ((n + 15) / 16) * 16;
        global_work_size[0] = padded_m;
        global_work_size[1] = padded_n;
        local_work_size[0] = 16;
        local_work_size[1] = 16;
    }

    // // Query the maximum work group size and set it
    // size_t max_work_group_size;
    // clGetKernelWorkGroupInfo(kernel, device_id, CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t), &max_work_group_size, NULL);
    // // Ensure local work size does not exceed the maximum work group size
    // local_work_size[0] = 16;
    // local_work_size[1] = 16;
    // if (local_work_size[0] * local_work_size[1] > max_work_group_size) {
    //     local_work_size[0] = max_work_group_size / 16;
    //     local_work_size[1] = 16;
    // }

    // add gpu name to the log
    state.SetLabel(device_name);
    for (auto _: state) {
        cl_event event = nullptr;
        cl_ulong time_start = 0, time_end = 0;

        err = clEnqueueNDRangeKernel(command_queue, kernel, work_dim, NULL, global_work_size, local_work_size, 0, NULL, &event);
        checkError(err, "Enqueueing kernel");
        clWaitForEvents(1, &event); // Wait for kernel to finish
        clGetEventProfilingInfo(event, CL_PROFILING_COMMAND_START, sizeof(time_start), &time_start, NULL);
        clGetEventProfilingInfo(event, CL_PROFILING_COMMAND_END, sizeof(time_end), &time_end, NULL);
        cl_ulong elapsed = time_end - time_start;
        // Read results back to host
        clEnqueueReadBuffer(command_queue, buffer_c, CL_TRUE, 0, m * n * sizeof(float), C->data.data(), 0, NULL, NULL);

        // Print first 10 elements of the result
//        for (int i = 0; i < 10; ++i) {
//            std::cout << C[i] << " ";
//        }
        state.SetIterationTime(elapsed * 1e-9);
        clReleaseEvent(event);
    }

    // Clean up
    clReleaseKernel(kernel);
    clReleaseProgram(program);
    clReleaseCommandQueue(command_queue);
    clReleaseContext(context);
    clReleaseMemObject(buffer_a);
    clReleaseMemObject(buffer_b);
    clReleaseMemObject(buffer_c);
    free(platforms);
    delete A;
    delete B;
    delete C;

}
#endif

//Args format (m, n, k, Sp.TileSize1, Sp.TileSize2, chunk size, number of threads, samplingRatePercentage)
BENCHMARK_CAPTURE(BM_GEMM, gemm_optimized, swiftware::hpp::gemmEfficientParallel)
    ->Args({512, 512, 512, 256, 32, 1, NUM_THREADS, 1})
    ->Args({1024, 1024, 1024, 256, 32, 1, NUM_THREADS, 1})
    ->Args({2048, 2048, 2048, 256, 32, 1, NUM_THREADS, 1})
    ->Args({4096, 4096, 4096, 256, 32, 1, NUM_THREADS, 1});

#ifdef __OPENCL__
// Args format (m, n, k, work_dim)
BENCHMARK_CAPTURE(BM_MATMUL_OPENCL, opencl_matmul_v1, KernelSourceV1, "matmul_v1")
    ->Args({512, 512, 512, 1})->UseManualTime()->Iterations(100);

BENCHMARK_CAPTURE(BM_MATMUL_OPENCL, opencl_matmul_v2, KernelSourceV2, "matmul_v2")
    ->Args({512, 512, 512, 2})->UseManualTime()->Iterations(100);

BENCHMARK_CAPTURE(BM_MATMUL_OPENCL, opencl_matmul_v3, KernelSourceV3, "matmul_v3")
    ->Args({512, 512, 512, 2})->UseManualTime()->Iterations(100);

#endif


BENCHMARK_MAIN();

