// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab


#include <iostream>
#include <benchmark/benchmark.h>

#include "spmv.h"
#include "def.h"
#include "utils.h"
#include "gemv.h"


static void BM_GEMV(benchmark::State &state,
                    void (*gemvImpl1)(int M, int N, const float *A, const float *b, float *c,
                                      swiftware::hpp::ScheduleParams Sp)) {
  int m = state.range(0);
  int n = state.range(1);
  int t1 = state.range(2);
  int t2 = state.range(3);
  int srPercentage = state.range(4);

  auto *A = new swiftware::hpp::DenseMatrix(m, n);
  auto *B = new swiftware::hpp::DenseMatrix(n, 1);
  auto *C = new swiftware::hpp::DenseMatrix(m, 1);

  for (int i = 0; i < m * n; ++i) {
    A->data[i] = 1.0;
  }
  for (int i = 0; i < n; ++i) {
    B->data[i] = 1.0;
  }

  float samplingRate = (float)srPercentage / 100.;
  auto* sampledA = swiftware::hpp::samplingDense(A, samplingRate);

  for (auto _: state) {
    gemvImpl1(m, n, sampledA->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(t1, t2));
  }

  delete A;
  delete B;
  delete C;
  delete sampledA;
}

static void BM_SPMV(benchmark::State &state,
                    void (*spmvImpl1)(int M, int N, const int *Ap, const int *Ai, const float *Ax, const float *b, float *c,
                                      swiftware::hpp::ScheduleParams Sp)) {
  int m = state.range(0);
  int n = state.range(1);
  int t1 = state.range(2);
  int t2 = state.range(3);
  int srPercentage = state.range(4);

  auto *A = new swiftware::hpp::DenseMatrix(m, n);
  auto *B = new swiftware::hpp::DenseMatrix(n, 1);
  auto *C = new swiftware::hpp::DenseMatrix(m, 1);

  for (int i = 0; i < m * n; ++i) {
    A->data[i] = 1.0;
  }
  for (int i = 0; i < n; ++i) {
    B->data[i] = 1.0;
  }

  float samplingRate = (float)srPercentage / 100.;
  auto* sampledA = swiftware::hpp::samplingDense(A, samplingRate);

  // Convert A to CSR
  auto *ACSR = swiftware::hpp::dense2CSR(sampledA);

  for (auto _: state) {
    spmvImpl1(m, n, ACSR->rowPtr.data(), ACSR->colIdx.data(), ACSR->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(t1, t2));
  }

  delete A;
  delete B;
  delete C;
  delete sampledA;
  delete ACSR;
}


// SPMVArgs = (m, n, t1, t2, srPercentage)
// GEMVArgs = (m, n, t1, t2, srPercentage)
BENCHMARK_CAPTURE(BM_SPMV, baseline_spmv_csr, swiftware::hpp::spmvCSR)
  ->Args({512, 512, 512, -1, 1})
  ->Args({1024, 1024, 1024, -1, 1})
  ->Args({2048, 2048, 2048, -1, 1})
  ->Args({4096, 4096, 4096, -1, 1});

BENCHMARK_CAPTURE(BM_SPMV, optimized_spmv_csr, swiftware::hpp::spmvCSROptimized)
  ->Args({512, 512, 512, 32, 1})
  ->Args({1024, 1024, 1024, 32, 1})
  ->Args({2048, 2048, 2048, 32, 1})
  ->Args({4096, 4096, 4096, 32, 1});

// following lines to test affect of srPercentage on performance
// ->Args({1024, 1024, 1, -1, 1})
// ->Args({1024, 1024, 1, -1, 5})
// ->Args({1024, 1024, 1, -1, 10})
// ->Args({1024, 1024, 1, -1, 25})
// ->Args({1024, 1024, 1, -1, 50})
// ->Args({1024, 1024, 1, -1, 100});


BENCHMARK_CAPTURE(BM_GEMV, spmv_skipping, swiftware::hpp::spmvSkipping)
  ->Args({512, 512, 512, 256, 1})
  ->Args({1024, 1024, 1024, 256, 1})
  ->Args({2048, 2048, 2048, 256, 1})
  ->Args({4096, 4096, 4096, 256, 1});

BENCHMARK_CAPTURE(BM_GEMV, gemv_optimized, swiftware::hpp::gemvVec)
  ->Args({512, 512, 512, 256, 1})
  ->Args({1024, 1024, 1024, 256, 1})
  ->Args({2048, 2048, 2048, 256, 1})
  ->Args({4096, 4096, 4096, 256, 1});

// following lines to test affect of srPercentage on performance
// ->Args({1024, 1024, 1, -1, 1})
// ->Args({1024, 1024, 1, -1, 5})
// ->Args({1024, 1024, 1, -1, 10})
// ->Args({1024, 1024, 1, -1, 25})
// ->Args({1024, 1024, 1, -1, 50})
// ->Args({1024, 1024, 1, -1, 100});




BENCHMARK_MAIN();
