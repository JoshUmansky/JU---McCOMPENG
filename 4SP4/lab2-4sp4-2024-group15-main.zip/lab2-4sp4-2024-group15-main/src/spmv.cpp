// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include "spmv.h"
#include "immintrin.h"

namespace swiftware::hpp {
  void spmvCSR(int m, int n, const int *Ap, const int *Ai, const float *Ax, const float *b, float *c, ScheduleParams Sp){
    for (int i = 0; i < m; ++i) {
      c[i] = 0;
      for (int l = Ap[i]; l < Ap[i + 1]; ++l) {
        c[i] += Ax[l] * b[Ai[l]];
      }
    }
  }

  void spmvCSROptimized(int m, int n, const int *Ap, const int *Ai, const float *Ax, const float *b, float *c, ScheduleParams Sp){
    for (int i = 0; i < m; ++i) {
      __m256 sum_vec = _mm256_setzero_ps(); // Initialize a vector of zeros
      int row_start = Ap[i];
      int row_end = Ap[i + 1];
      int j;

      // Process 8 elements at a time
      for (j = row_start; j <= row_end - 8; j += 8) {
        __m256 ax_vec = _mm256_loadu_ps(&Ax[j]); // Load 8 elements from Ax
        __m256 b_vec = _mm256_set_ps(b[Ai[j + 7]], b[Ai[j + 6]], b[Ai[j + 5]], b[Ai[j + 4]], b[Ai[j + 3]], b[Ai[j + 2]], b[Ai[j + 1]], b[Ai[j]]); // Load 8 elements from b
        __m256 mul_vec = _mm256_mul_ps(ax_vec, b_vec); // Multiply Ax and b vectors
        sum_vec = _mm256_add_ps(sum_vec, mul_vec); // Accumulate the results
      }

      // Horizontal sum of the vector sum_vec
      float sum_array[8];
      _mm256_storeu_ps(sum_array, sum_vec);
      float sum = sum_array[0] + sum_array[1] + sum_array[2] + sum_array[3] + sum_array[4] + sum_array[5] + sum_array[6] + sum_array[7];

      // Process remaining elements
      for (; j < row_end; ++j) {
        sum += Ax[j] * b[Ai[j]];
      }

      c[i] = sum;
    }

    // tiled implementation -- slower than vectorization
    // int tileSize = Sp.TileSize1;
    // for (int i1 = 0; i1 < m; i1 += tileSize) {
    //   for (int i = i1; i < std::min(i1 + tileSize, m); ++i) {
    //     c[i] = 0; // Initialize c[i] within the inner loop
    //     for (int l = Ap[i]; l < Ap[i + 1]; ++l) {
    //       int j = Ai[l];
    //       c[i] += Ax[l] * b[j];
    //     }
    //   }
    // }
  }

  void spmvSkipping(int m, int n, const float *A, const float *b, float *c, ScheduleParams Sp){
    int s = Sp.TileSize1;
    for (int i1 = 0; i1 < m; i1 += s) {
      for (int j1 = 0; j1 < n; j1 += s) {
        for (int i = i1; i < std::min(i1 + s, m); ++i) {
          float sum = 0;
          for (int j = j1; j < std::min(j1 + s, n); ++j) {
            float A_ij = A[i * n + j];
            if (A_ij != 0 && b[j] != 0) {
              sum += A_ij * b[j];
            }
          }
          c[i] += sum;
        }
      }
    }
    // No tiling
    // for (int i = 0; i < m; ++i) {
    //   float sum = 0;
    //   for (int j = 0; j < n; ++j) {
    //     float A_ij = A[i * n + j];
    //     if (A_ij != 0 && b[j] != 0) {
    //       sum += A_ij * b[j];
    //     }
    //   }
    //   c[i] = sum;
    // }
  }
}