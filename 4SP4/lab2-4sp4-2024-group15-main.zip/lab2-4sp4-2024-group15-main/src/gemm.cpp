// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab



#include "gemm.h"
#include <immintrin.h>

namespace swiftware::hpp {

  void gemmVectorized(int m, int n, int k, const float *A, const float *B, float *C, ScheduleParams Sp) {
    for (int i = 0; i < m; i++) {
      for (int j = 0; j < n; j += 8) {
        __m256 sum = _mm256_setzero_ps();
        for (int l = 0; l < k; l++) {
          __m256 a = _mm256_set1_ps(A[i * k + l]);
          __m256 b = _mm256_loadu_ps(&B[l * n + j]);
          sum = _mm256_add_ps(sum, _mm256_mul_ps(a, b));
        }
        if (j + 8 <= n) {
          _mm256_storeu_ps(&C[i * n + j], sum);
        } else {
          // Handle the remaining elements if n is not a multiple of 8
          float temp[8];
          _mm256_storeu_ps(temp, sum);
          for (int j0 = 0; j0 < n - j; j0++) {
            C[i * n + j + j0] = temp[j0];
          }
        }
      }
    }
  }

}