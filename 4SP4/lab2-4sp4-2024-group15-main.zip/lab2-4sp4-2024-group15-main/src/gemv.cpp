// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab


#include "gemv.h"
#include <immintrin.h>

namespace swiftware::hpp {

  void gemvVec(int m, int n, const float *A, const float *x, float *y, ScheduleParams Sp) {
    int blocks = n - (n%8);
    for (int i = 0; i < m; ++i) {
      __m256 sum = _mm256_setzero_ps();
      int j=0;
      for (; j < blocks; j += 8) {
        __m256 a = _mm256_loadu_ps(&A[i * n + j]);
        __m256 b = _mm256_loadu_ps(&x[j]);
        sum = _mm256_add_ps(sum, _mm256_mul_ps(a, b));
      }

      sum = _mm256_hadd_ps(sum, sum);
      sum = _mm256_hadd_ps(sum, sum);
      float temp[8];
      _mm256_storeu_ps(temp, sum);
      y[i] = temp[0] + temp[4];
      for(; j<n; ++j) {
        y[i] += A[i*n+j] * x[j];
      }
    }
  }

}