// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include "spmm.h"
#include <immintrin.h>

namespace swiftware::hpp {

  void spmmCSR(int m, int n, int k, const int *Ap, const int *Ai, const float *Ax, const float *B, float *C, ScheduleParams Sp) {
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        C[i * n + j] = 0;
        for (int l = Ap[i]; l < Ap[i + 1]; ++l) {
          C[i * n + j] += Ax[l] * B[Ai[l] * n + j];
        }
      }
    }
  }

  void spmmSkipping(int m, int n, int k, const float *A, const float *B, float *C, ScheduleParams Sp) {
    int tileSize = Sp.TileSize1;
    for (int i1 = 0; i1 < m; i1 += tileSize) {
      for (int j1 = 0; j1 < n; j1 += tileSize) {
        for (int l1 = 0; l1 < k; l1 += tileSize) {
          int imax = (i1 + tileSize < m) ? i1 + tileSize : m;
          int jmax = (j1 + tileSize < n) ? j1 + tileSize : n;
          int lmax = (l1 + tileSize < k) ? l1 + tileSize : k;
          for (int i = i1; i < imax; ++i) {
            for (int j = j1; j < jmax; ++j) {
              float sum = 0;
              for (int l = l1; l < lmax; ++l) {
                if (A[i * k + l] != 0 && B[l * n + j] != 0) {
                  sum += A[i * k + l] * B[l * n + j];
                }
              }
              C[i * n + j] += sum;
            }
          }
        }
      }
    }
  }

// function that has tiling and best performance
  void spmmCSROptimized(int m, int n, int k, const int *Ap, const int *Ai, const float *Ax, const float *B, float *C, ScheduleParams Sp) {
    int tileSize = Sp.TileSize1;
    for (int i1 = 0; i1 < m; i1 += tileSize) {
      for (int j1 = 0; j1 < n; j1 += tileSize) {
        int imax = (i1 + tileSize < m) ? i1 + tileSize : m;
        int jmax = (j1 + tileSize < n) ? j1 + tileSize : n;
        for (int i = i1; i < imax; ++i) {
          for (int j = j1; j < jmax; ++j) {
            C[i * n + j] = 0;
            for (int l = Ap[i]; l < Ap[i + 1]; ++l) {
              C[i * n + j] += Ax[l] * B[Ai[l] * n + j];
            }
          }
        }
      }
    }
  }

// Function that has vectorization
/*
  void spmmCSROptimized(int m, int n, int k, const int *Ap, const int *Ai, const float *Ax, const float *B, float *C, ScheduleParams Sp) {
    int vector_width = 8;
    for (int i = 0; i < m; i++) {
      for (int j = 0; j < n; j++) {
        __m256 sum = _mm256_setzero_ps();
        int row_start = Ap[i];
        int row_end = Ap[i + 1];
        int l;

        // Prefetching
        for (l = row_start; l + vector_width <= row_end; l += vector_width) {
          _mm_prefetch((const char*)&Ax[l + vector_width], _MM_HINT_T0);
          _mm_prefetch((const char*)&Ai[l + vector_width], _MM_HINT_T0);

          __m256 valAx = _mm256_loadu_ps(&Ax[l]);
          __m256 valB = _mm256_set_ps(
              B[Ai[l + 7] * n + j],
              B[Ai[l + 6] * n + j],
              B[Ai[l + 5] * n + j],
              B[Ai[l + 4] * n + j],
              B[Ai[l + 3] * n + j],
              B[Ai[l + 2] * n + j],
              B[Ai[l + 1] * n + j],
              B[Ai[l] * n + j]
          );
          sum = _mm256_fmadd_ps(valAx, valB, sum);
        }

        // Scalar part to handle edge cases at end of rows
        float scalar_sum = 0.0;
        for (; l < row_end; l++) {
          scalar_sum += Ax[l] * B[Ai[l] * n + j];
        }

        // Horizontal sum of the SIMD register
        sum = _mm256_hadd_ps(sum, sum);
        sum = _mm256_hadd_ps(sum, sum);
        float buffer[8] __attribute__((aligned(32)));
        _mm256_store_ps(buffer, sum);
        scalar_sum += buffer[0] + buffer[4];

        C[i * n + j] = scalar_sum;
      }
    }
  }
  */

// Function that has the better performance compared to vectorization, referenced in report directly*****************************************
/*void spmmCSROptimized(int m, int n, int k, const int *Ap, const int *Ai, const float *Ax, const float *B, float *C, ScheduleParams Sp) {

    for (int i = 0; i < m; i++) {
      for (int j = 0; j < n; j++) {
        float sum = 0;
        int row_start = Ap[i];
        int row_end = Ap[i + 1];
        for (int k = row_start; k < row_end; k++) {
          sum += Ax[k] * B[Ai[k] * n + j];
        }
        C[i * n + j] = sum;
      }
    }
  }*/

}