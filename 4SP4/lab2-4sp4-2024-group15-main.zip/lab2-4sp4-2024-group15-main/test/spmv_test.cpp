// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include "spmv.h"
#include <gtest/gtest.h>

#include <utils.h>

namespace swiftware::hpp {

// helper function to generate and populate array with random data for testing
void populate_array(float* array, int size)
{
  std::srand(static_cast<unsigned int>(std::time(0)));
  for (int i = 0; i < size; ++i) {
    array[i] = 1 + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (1000 - 1)));
  }
}

// Small test copied from Lab 1
TEST(SPMVTest, SmallTest) {
  int m = 2;
  int n = 2;
  float A[4] = {1, 2, 3, 4};
  float B[2] = {1, 2};
  float C[2] = {0, 0};
  swiftware::hpp::spmvSkipping(m, n, A, B,  C, swiftware::hpp::ScheduleParams(32, 32));
  float expected[2] = {5, 11};
  for (int i = 0; i < m; ++i) {
    EXPECT_EQ(C[i], expected[i]);
  }
}

TEST(SPMVTest, BaseTest) {
  int m = 4;
  int n = 4;
  float A[16] = {0, 2, 3, 4, 5, 0, 7, 8, 9, 10, 0, 12, 13, 14, 15, 0};
  auto A1 = new DenseMatrix(4, 4);
  A1->data = {0, 2, 3, 4, 5, 0, 7, 8, 9, 10, 0, 12, 13, 14, 15, 0};
  auto test = swiftware::hpp::dense2CSR(A1);
  float B[4] = {0, 2, 3, 4};
  float C[4] = {0};
  float expected[4] = {0};
  swiftware::hpp::spmvSkipping(m, n, A, B, C, swiftware::hpp::ScheduleParams(1, 1));
  swiftware::hpp::spmvCSR(m, n, test->rowPtr.data(), test->colIdx.data(), test->data.data(), B, expected, swiftware::hpp::ScheduleParams(-1, -1));
  for (int i = 0; i < m; ++i) {
    EXPECT_EQ(C[i], expected[i]);
  }

  delete A1;
  delete test;
}

TEST(SPMVTest, BaseOptimizedTest) {
  int m = 4;
  int n = 4;
  float A[16] = {0, 2, 3, 4, 5, 0, 7, 8, 9, 10, 0, 12, 13, 14, 15, 0};
  auto A1 = new DenseMatrix(4, 4);
  A1->data = {0, 2, 3, 4, 5, 0, 7, 8, 9, 10, 0, 12, 13, 14, 15, 0};
  auto test = swiftware::hpp::dense2CSR(A1);
  float B[4] = {0, 2, 3, 4};
  float C[4] = {0};
  float expected[4] = {0};
  swiftware::hpp::spmvSkipping(m, n, A, B, C, swiftware::hpp::ScheduleParams(1, 1));
  swiftware::hpp::spmvCSROptimized(m, n, test->rowPtr.data(), test->colIdx.data(), test->data.data(), B, expected, swiftware::hpp::ScheduleParams(-1, -1));
  for (int i = 0; i < m; ++i) {
    EXPECT_EQ(C[i], expected[i]);
  }

  delete A1;
  delete test;
}

TEST(GEMVTest, LargeTest) {
  int m = 20;
  int n = 20;
  auto A = new DenseMatrix(m, n);
  populate_array(A->data.data(), m*n);
  auto b = new DenseMatrix(m, 1);
  populate_array(b->data.data(), m);
  auto c = new DenseMatrix(m, 1);
  auto expected = new DenseMatrix(m, 1);
  int srPercentage = 30;
  float samplingRate = (float)srPercentage / 100.;
  auto* sampledA = swiftware::hpp::samplingDense(A, samplingRate);
  auto *test = swiftware::hpp::dense2CSR(sampledA);
  swiftware::hpp::spmvSkipping(m, n, sampledA->data.data(), b->data.data(), c->data.data(), swiftware::hpp::ScheduleParams(1, 1));
  swiftware::hpp::spmvCSROptimized(m, n, test->rowPtr.data(), test->colIdx.data(), test->data.data(), b->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(-1, -1));
  for (int i = 0; i < m; ++i) {
    EXPECT_NEAR(c->data[i], expected->data[i], 1e-2);
  }
  delete A;
  delete b;
  delete c;
  delete expected;
  delete sampledA;
  delete test;
}
}