// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab


#ifndef LAB3_INTEGRATION_H
#define LAB3_INTEGRATION_H

#include "def.h"

namespace swiftware::hpp {


// please do not change below
struct IntegrationParams {
  int NumSteps;
  double Sum;
  double StepSize;
  double PI;
  IntegrationParams(int numSteos) : NumSteps(numSteos), Sum(0.0), StepSize(1.0 / numSteos), PI(0.0) {}
};

void integrateSequential(IntegrationParams *params, ScheduleParams sp);
void integrateParallel(IntegrationParams *params, ScheduleParams sp);
void integrateParallelWithAllOMP(IntegrationParams *params, ScheduleParams sp);

} // namespace swiftware::hpp

#endif // LAB3_INTEGRATION_H
