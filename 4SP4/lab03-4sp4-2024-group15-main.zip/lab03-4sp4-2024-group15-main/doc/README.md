# Report

Please prepare a report that has the requested details.
- Figures should have caption and number
- Tables should have caption and number
- Figures should be explained in the text
- Make one section for each part of the lab
- Provide details on how you have obtained results such as matrix size, ...
- Make one section per each part. No need to include background sections and similar sections.
