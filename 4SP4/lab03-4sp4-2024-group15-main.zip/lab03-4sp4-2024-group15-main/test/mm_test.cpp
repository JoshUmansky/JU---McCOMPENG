// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include "gemm.h"
#include "spmm.h"
#include <gtest/gtest.h>

#include <utils.h>

namespace swiftware::hpp {
  // helper function to fill in arrays with random values
  void populate_array(float* array, int size)
  {
    std::srand(static_cast<unsigned int>(std::time(0)));
    for (int i = 0; i < size; ++i) {
      array[i] = 1 + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (1000 - 1)));
    }
  }

  TEST(MMTest, SmallTest) {
    int m = 2;
    int n = 2;
    int k = 2;
    // TODO generate random sparse matrices
    float A[4] = {1, 2, 3, 4};
    float B[4] = {1, 2, 3, 4};
    float C[4] = {0, 0, 0, 0};
    swiftware::hpp::gemmEfficientParallel(m, n, k, A, B, C, swiftware::hpp::ScheduleParams(64, 32, 8, 8));
    float expected[4] = {7, 10, 15, 22};
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C[i * n + j], expected[i * n + j]);
      }
    }
  }

  TEST(MMTest, TallSkinnyTest) {
    int k = 5;
    int m = 100 * k;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k); // populate A with random values
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    swiftware::hpp::gemmEfficientParallel(m, n, k, A->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, 32, 8, 8));
    swiftware::hpp::gemmEfficientSequential(m, n, k, A->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(32, 32, 8, 1));

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete B;
    delete C;
    delete expected;
  }

  TEST(MMTest, SquareTest) {
    int k = 16;
    int m = 16;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k); // populate A with random values
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    swiftware::hpp::gemmEfficientParallel(m, n, k, A->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, 32, 8, 8));
    swiftware::hpp::gemmEfficientSequential(m, n, k, A->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(32, 32, 8, 1));

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete B;
    delete C;
    delete expected;
  }

  TEST(MMTest, ShortWideTest) {
    int m = 5;
    int k = 100 * m;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k); // populate A with random values
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    swiftware::hpp::gemmEfficientParallel(m, n, k, A->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, 32, 8, 8));
    swiftware::hpp::gemmEfficientSequential(m, n, k, A->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(32, 32, 8, 1));

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete B;
    delete C;
    delete expected;
  }

  TEST(MMTest, TallSkinnyXLTest) {
    int k = 20;
    int m = 100 * k;
    int n = 32;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k); // populate A with random values
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    swiftware::hpp::gemmEfficientParallel(m, n, k, A->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, 32, 8, 8));
    swiftware::hpp::gemmEfficientSequential(m, n, k, A->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(32, 32, 8, 1));

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete B;
    delete C;
    delete expected;
  }

  TEST(MMTest, SquareXLTest) {
    int k = 32;
    int m = 32;
    int n = 32;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k); // populate A with random values
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    swiftware::hpp::gemmEfficientParallel(m, n, k, A->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, 32, 8, 8));
    swiftware::hpp::gemmEfficientSequential(m, n, k, A->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(32, 32, 8, 1));

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete B;
    delete C;
    delete expected;
  }

  TEST(MMTest, ShortWideXLTest) {
    int m = 20;
    int k = 100 * m;
    int n = 32;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k); // populate A with random values
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    swiftware::hpp::gemmEfficientParallel(m, n, k, A->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, 32, 8, 8));
    swiftware::hpp::gemmEfficientSequential(m, n, k, A->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(32, 32, 8, 1));

    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete B;
    delete C;
    delete expected;
  }

// ----------------------------- TESTING SPMM ----------------------------- //


  TEST(SPMMTest, TallSkinnyTest) {
    int k = 5;
    int m = 100 * k;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k);
    auto* sampledA = swiftware::hpp::samplingDense(A,0.5);
    auto *CSR = dense2CSR(sampledA);
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    spmmCSREfficientSequential(m, n, k, CSR->rowPtr.data(), CSR->colIdx.data(), CSR->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    gemmEfficientSequential(m, n, k, sampledA->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete sampledA;
    delete CSR;
    delete B;
    delete C;
    delete expected;
  }

  TEST(SPMMTest, ShortWideTest) {
    int m = 5;
    int k = 100 * m;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k);
    auto* sampledA = swiftware::hpp::samplingDense(A,0.5);
    auto *CSR = dense2CSR(sampledA);
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    spmmCSREfficientSequential(m, n, k, CSR->rowPtr.data(), CSR->colIdx.data(), CSR->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    gemmEfficientSequential(m, n, k, sampledA->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete sampledA;
    delete CSR;
    delete B;
    delete C;
    delete expected;
  }

  TEST(SPMMTest, SquareTest) {
    int m = 16;
    int k = 16;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k);
    auto* sampledA = swiftware::hpp::samplingDense(A,0.5);
    auto *CSR = dense2CSR(sampledA);
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *C = new DenseMatrix(m, n);
    C->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    spmmCSREfficientSequential(m, n, k, CSR->rowPtr.data(), CSR->colIdx.data(), CSR->data.data(), B->data.data(), C->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    gemmEfficientSequential(m, n, k, sampledA->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(C->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete sampledA;
    delete CSR;
    delete B;
    delete C;
    delete expected;
  }

  TEST(SPMMTest, TallSkinnyParallelTest) {
    int k = 5;
    int m = 100 * k;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k);
    auto* sampledA = swiftware::hpp::samplingDense(A,0.5);
    auto *CSR = dense2CSR(sampledA);
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *Cparallel = new DenseMatrix(m, n);
    Cparallel->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    spmmCSREfficientParallel(m, n, k, CSR->rowPtr.data(), CSR->colIdx.data(), CSR->data.data(), B->data.data(), Cparallel->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    gemmEfficientSequential(m, n, k, sampledA->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(Cparallel->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete sampledA;
    delete CSR;
    delete B;
    delete Cparallel;
    delete expected;
  }

  TEST(SPMMTest, ShortWideParallelTest) {
    int m = 5;
    int k = 100 * m;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k);
    auto* sampledA = swiftware::hpp::samplingDense(A,0.5);
    auto *CSR = dense2CSR(sampledA);
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *Cparallel = new DenseMatrix(m, n);
    Cparallel->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    spmmCSREfficientParallel(m, n, k, CSR->rowPtr.data(), CSR->colIdx.data(), CSR->data.data(), B->data.data(), Cparallel->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    gemmEfficientSequential(m, n, k, sampledA->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(Cparallel->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete sampledA;
    delete CSR;
    delete B;
    delete Cparallel;
    delete expected;
  }

  TEST(SPMMTest, SquareParallelTest) {
    int m = 16;
    int k = 16;
    int n = 16;

    auto *A = new DenseMatrix(m, k);
    populate_array(A->data.data(), m * k);
    auto* sampledA = swiftware::hpp::samplingDense(A,0.5);
    auto *CSR = dense2CSR(sampledA);
    auto *B = new DenseMatrix(k, n);
    populate_array(B->data.data(), k * n); // populate B with random values
    auto *Cparallel = new DenseMatrix(m, n);
    Cparallel->data = {0}; // fill with zeros
    auto *expected = new DenseMatrix(m, n);
    expected->data = {0}; // fill with zeros

    spmmCSREfficientParallel(m, n, k, CSR->rowPtr.data(), CSR->colIdx.data(), CSR->data.data(), B->data.data(), Cparallel->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    gemmEfficientSequential(m, n, k, sampledA->data.data(), B->data.data(), expected->data.data(), swiftware::hpp::ScheduleParams(64, -1, 8, 8));
    for (int i = 0; i < m; ++i) {
      for (int j = 0; j < n; ++j) {
        EXPECT_EQ(Cparallel->data[i * n + j], expected->data[i * n + j]);
      }
    }
    delete A;
    delete sampledA;
    delete CSR;
    delete B;
    delete Cparallel;
    delete expected;
  }
}