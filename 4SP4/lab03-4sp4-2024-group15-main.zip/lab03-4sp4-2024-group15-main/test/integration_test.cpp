// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab


#include <gtest/gtest.h>
#include "integration.h"
#include <math.h>

namespace swiftware::hpp {
  const double pi = 3.14159265358979323;

  int accuracy(double calculated) {
    double pie = pi;
    int digits = 1;
    if (calculated > 3.9 || calculated < 3.0) {
      return 0;
    }
    for (int i = 0; i < 17; i++) {
      calculated *= 10;
      pie *= 10;
      digits++;
      if (abs(trunc(calculated) - trunc(pie)) >= 1) {
        return digits - 1;
      }
    }
    return -1;
  }

  TEST(IntegrationTest, SmallTest) {
    // Set up the parameters
    IntegrationParams params(10);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateSequential(&params, sp);
    std::cout << "Sequential SmallTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-3);
  }

TEST(IntegrationTest, MediumTest) {
    // Set up the parameters
    IntegrationParams params(1000);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateSequential(&params, sp);
    std::cout << "Sequential MediumTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-6);
  }

  TEST(IntegrationTest, LargeTest) {
    // Set up the parameters
    IntegrationParams params(1000000);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateSequential(&params, sp);
    std::cout << "Sequential LargeTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-12);
  }

  TEST(integration_parallel_omp, SmallTestParallel) {
    // Set up the parameters
    IntegrationParams params(10);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateParallel(&params, sp);
    std::cout << "Restricted Parallel SmallTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-3);
  }

  TEST(integration_parallel_omp, MediumTestParallel) {
    // Set up the parameters
    IntegrationParams params(1000);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateParallel(&params, sp);
    std::cout << "Restricted Parallel MediumTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-6);
  }

  TEST(integration_parallel_omp, LargeTestParallel) {
    // Set up the parameters
    IntegrationParams params(1000000);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateParallel(&params, sp);
    std::cout << "Restricted Parallel LargeTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-12);
  }

  TEST(integration_parallel_omp, SmallTestParallelParallelwithAllOMP) {
    // Set up the parameters
    IntegrationParams params(10);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateParallelWithAllOMP(&params, sp);
    std::cout << "Parallel ALLOMP SmallTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-3);
  }

  TEST(integration_parallel_omp, MediumTestParallelParallelwithAllOMP) {
    // Set up the parameters
    IntegrationParams params(1000);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateParallelWithAllOMP(&params, sp);
    std::cout << "Parallel ALLOMP MediumTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-6);
  }

  TEST(integration_parallel_omp, LargeTestParallelParallelwithAllOMP) {
    // Set up the parameters
    IntegrationParams params(1000000);
    ScheduleParams sp(-1, -1, 8, 2);

    // Call the function to approximate pi
    integrateParallelWithAllOMP(&params, sp);
    std::cout << "Parallel ALLOMP LargeTest accuracy of calculation is to: " << accuracy(params.PI) << " digits" << std::endl;

    // Check that the approximation is close to the true value of pi
    EXPECT_NEAR(params.PI, pi, 1e-12);
  }
}