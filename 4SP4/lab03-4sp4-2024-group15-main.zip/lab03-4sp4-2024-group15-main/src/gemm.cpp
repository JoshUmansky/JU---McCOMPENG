// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab



#include "gemm.h"
#include <omp.h>

namespace swiftware::hpp {

  void gemmEfficientSequential(int m, int n, int k, const float *A, const float *B, float *C, ScheduleParams Sp) {
    int tileSize = Sp.TileSize1;

    for (int i1 = 0; i1 < m; i1 += tileSize) {
      for (int j1 = 0; j1 < n; j1 += tileSize) {
        for (int l1 = 0; l1 < k; l1 += tileSize) {
          int imax = (i1 + tileSize < m) ? i1 + tileSize : m;
          int jmax = (j1 + tileSize < n) ? j1 + tileSize : n;
          int lmax = (l1 + tileSize < k) ? l1 + tileSize : k;
          for (int i = i1; i < imax; ++i) {
            for (int j = j1; j < jmax; ++j) {
              for (int l = l1; l < lmax; ++l) {
                C[i * n + j] += A[i * k + l] * B[l * n + j];
              }
            }
          }
        }
      }
    }
  }

  void gemmEfficientParallel(int m, int n, int k, const float *A, const float *B, float *C, ScheduleParams Sp) {
    omp_set_num_threads(Sp.NumThreads);
    float ratio = static_cast<float>(m) / k;

    if (ratio >= 100) { // If the matrix is tall-skinny
      #pragma omp parallel for collapse(2) schedule(dynamic, Sp.ChunkSize)
      for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
          #pragma omp simd
          for (int l = 0; l < k; ++l) {
            C[i * n + j] += A[i * k + l] * B[l * n + j];
          }
        }
      }
    }

    else if (ratio <= 0.01) { // If the matrix is short-wide
      #pragma omp parallel for collapse(2) schedule(guided, Sp.ChunkSize)
      for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
          #pragma omp simd
          for (int l = 0; l < k; ++l) {
            C[i * n + j] += A[i * k + l] * B[l * n + j];
          }
        }
      }
    }

    else { // If the matrix is square or close to square
      int TS = Sp.TileSize1;
      #pragma omp parallel for collapse(2) schedule(static, Sp.ChunkSize)
      for (int i0 = 0; i0 < m; i0 += TS) {
        for (int j0 = 0; j0 < n; j0 += TS) {
          for (int l0 = 0; l0 < k; l0 += TS) {
            int imax = (i0 + TS < m) ? (i0 + TS) : m;
            int jmax = (j0 + TS < n) ? (j0 + TS) : n;
            int lmax = (l0 + TS < k) ? (l0 + TS) : k;
            for (int i = i0; i < imax; ++i) {
              for (int j = j0; j < jmax; ++j) {
                #pragma omp simd
                for (int l = l0; l < lmax; ++l) {
                  C[i * n + j] += A[i * k + l] * B[l * n + j];
                }
              }
            }
          }
        }
      }
    }
  }
}