// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include "spmm.h"
#include <omp.h>

namespace swiftware::hpp {

  void spmmCSREfficientSequential(int m, int n, int k, const int *Ap, const int *Ai, const float *Ax, const float *B, float *C, ScheduleParams Sp) {
    int tileSize = Sp.TileSize1;
    for (int i1 = 0; i1 < m; i1 += tileSize) {
      for (int j1 = 0; j1 < n; j1 += tileSize) {
        int imax = (i1 + tileSize < m) ? i1 + tileSize : m;
        int jmax = (j1 + tileSize < n) ? j1 + tileSize : n;
        for (int i = i1; i < imax; ++i) {
          for (int j = j1; j < jmax; ++j) {
            C[i * n + j] = 0;
            for (int l = Ap[i]; l < Ap[i + 1]; ++l) {
              C[i * n + j] += Ax[l] * B[Ai[l] * n + j];
            }
          }
        }
      }
    }
  }

  void spmmCSREfficientParallel(int m, int n, int k, const int *Ap, const int *Ai, const float *Ax, const float *B, float *C, ScheduleParams Sp) {
    omp_set_num_threads(Sp.NumThreads);
    int tileSize = Sp.TileSize1;

    #pragma omp parallel for collapse(2) schedule(dynamic, Sp.ChunkSize)
    for (int i1 = 0; i1 < m; i1 += tileSize) {
      for (int j1 = 0; j1 < n; j1 += tileSize) {
        int imax = std::min(i1 + tileSize, m);
        int jmax = std::min(j1 + tileSize, n);
        for (int i = i1; i < imax; ++i) {
          for (int j = j1; j < jmax; ++j) {
            C[i * n + j] = 0;
            #pragma omp simd
            for (int l = Ap[i]; l < Ap[i + 1]; ++l) {
              C[i * n + j] += Ax[l] * B[Ai[l] * n + j];
            }
          }
        }
      }
    }
  }

}