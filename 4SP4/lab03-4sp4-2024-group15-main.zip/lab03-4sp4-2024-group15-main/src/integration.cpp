// Created by SwiftWare Lab on 9/24.
// CE 4SP4 - High Performance Programming
// Copyright (c) 2024 SwiftWare Lab

#include "integration.h"
#include <omp.h>

namespace swiftware::hpp {

  void integrateSequential(IntegrationParams *params, ScheduleParams sp) {
    double pi = 0.0;
    params->StepSize = 1.0 / params->NumSteps; // h = 1 / n;
    for (int i = 0; i < params->NumSteps; i++) {
      double x = (i + 0.5) * params->StepSize; // Midpoint; 0.5h, 1.5h, 2.5h, ..., nh
      params->Sum += 1.0 / (1.0 + x * x); //f(x) = [1.0 / (1.0 + x * x)]
    }
    pi = 4 * params->Sum * params->StepSize; // Integral = 4 * h * (sum of f(x))
    params->PI = pi;
  }

  void integrateParallel(IntegrationParams *params, ScheduleParams sp) {
    omp_set_num_threads(sp.NumThreads);
    double pi = 0.0;
    params->StepSize = 1.0 / params->NumSteps; // h = 1 / n
    int num_threads = sp.NumThreads;
    double *thread_sums = new double[num_threads](); // store each threads val

    #pragma omp parallel
      {
        int thread_id = omp_get_thread_num();
        double thread_sum = 0.0;
        for (int i = thread_id; i < params->NumSteps; i += num_threads) {
          double x = (i + 0.5) * params->StepSize;
          thread_sum += 1.0 / (1.0 + x * x);
        }
        thread_sums[thread_id] = thread_sum;
      }
    for (int i = 0; i < num_threads; i++) { // accumulate all thread sums
      pi += thread_sums[i];
    }

    pi = 4 * pi * params->StepSize;
    params->PI = pi;
    delete[] thread_sums;
  }

  void integrateParallelWithAllOMP(IntegrationParams *params, ScheduleParams sp) {
    omp_set_num_threads(sp.NumThreads);
    double pi = 0.0;
    params->StepSize = 1.0 / params->NumSteps; // h = 1 / n
    double global_sum = 0.0;
    
    #pragma omp parallel for simd reduction(+:global_sum) schedule(static, sp.ChunkSize)
    for (int i = 0; i < params->NumSteps; i++) {
      double x = (i + 0.5) * params->StepSize;
      global_sum += 1.0 / (1.0 + x * x);
    }
    
    pi = 4 * global_sum * params->StepSize;
    params->PI = pi;
  }
}
